Place uploaded JPG or PNG service photos in this folder.
