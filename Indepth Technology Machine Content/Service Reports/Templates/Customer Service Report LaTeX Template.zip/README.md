# Service Report v2 - LaTeX template

This bundle contains a reusable, customer-facing service-report template with the PPT / InDepth Technology Ltd logo built into the header.

## Fast workflow

1. Open `service_report_v2.tex`.
2. Edit only the clearly marked **REPORT DATA** block near the top.
3. Put uploaded service photos in the `photos` folder.
4. Add either of these commands to `\ReportPhotos`:

   ```tex
   \ServicePhoto{photo-01.jpg}{Machine after service}
   \ServicePhotoPair{photo-01.jpg}{Before}{photo-02.jpg}{After}
   ```

5. Remove the `\PhotoPlaceholder` line when real photos are present.
6. Compile twice so the footer page count updates.

## Compile locally

With a standard TeX Live or MiKTeX installation:

```text
pdflatex service_report_v2.tex
pdflatex service_report_v2.tex
```

Or use:

```text
latexmk -pdf service_report_v2.tex
```

## Use in Overleaf

Upload the complete unzipped folder as a new project, then set `service_report_v2.tex` as the main document. The logo path is already configured.

## Photo guidance

- Use JPG or PNG images.
- Rename files to short names without spaces, such as `photo-01.jpg`.
- Use `\ServicePhotoPair` for two portrait or detail images.
- Use `\ServicePhoto` for a wide machine image or when maximum detail is useful.
- Missing images produce a labelled placeholder instead of stopping compilation.

## Customer-facing wording

- Summarise completed work clearly and factually.
- Use `General maintenance.` when no more specific reason is needed.
- Keep internal future-maintenance planning out of the customer copy unless it is deliberately requested.
- Use `Not applicable for this report.` when the further-action field should not contain internal follow-up notes.

## LaTeX characters

Escape these characters when they appear in report text:

```text
&  -> \&
%  -> \%
#  -> \#
_  -> \_
```

